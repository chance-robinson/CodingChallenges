applicant: Chance Robinson
date: 1/6/2021

instructions: to run this program type in the command line "make" then run "./roman"
time spent: 2 hours + 2 hours polishing = 4 total

additional notes: 
I used recursion to make this program run to users satisfaction
I used a class NumberCoversions class to demonstrate that I have a basic understanding of Object Oriented Programming
Used additional functions to keep the main() as simple as possible
Did not use pointers (as such no memory leaks)