#include <iostream>
using namespace std;

class NumberConversions {
public:
	int values_roman(char x);

	int roman_to_modern(string user_input);

	string modern_to_roman(int input);
};